define(function (require) {

    return Backbone.Collection;
});
