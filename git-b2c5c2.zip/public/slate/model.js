define(function (require) {

    return Backbone.Model;
});
