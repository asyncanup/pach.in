define(function (require) {
    
    return Handlebars;
});
