TODO
====

- Extend `view` to have common `initialize` and `render` behaviour like logging.
- 
