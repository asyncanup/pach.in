define(function (require) {

    return Backbone.Events;
});
