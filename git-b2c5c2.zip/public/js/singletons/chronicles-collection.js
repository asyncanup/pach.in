define(function (require) {
    
    var ChroniclesCollection = require("models/chronicles-collection");
    
    return new ChroniclesCollection();
});
