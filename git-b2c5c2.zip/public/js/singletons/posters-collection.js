define(function (require) {
    
    var PostersCollection = require("models/posters-collection");
    
    return new PostersCollection();
});
