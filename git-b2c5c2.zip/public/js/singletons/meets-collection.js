define(function (require) {
    
    var MeetsCollection = require("models/meets-collection");
    
    return new MeetsCollection();
});
