define(function (require) {
    
    var SubscriptionModel = require("models/subscription-model");
    
    return new SubscriptionModel();
});
